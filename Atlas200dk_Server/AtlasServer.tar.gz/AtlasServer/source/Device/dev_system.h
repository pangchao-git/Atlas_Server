#ifndef DEV_SYSTEM_H
#define DEV_SYSTEM_H
#include <string>

int CurrentDateTime(std::string &timeStr, std::string &timeZone);

#endif
